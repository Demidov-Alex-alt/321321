class CPerson:
    def __init__(self):
        self.fullName = ""
        self.day = 0
        self.month = 0
        self.year = 0
        self.gender = ""

    def setFullName(self, name):
        self.fullName = name

    def setBirthdate(self, d, m, y):
        self.day = d
        self.month = m
        self.year = y

    def setGender(self, g):
        self.gender = g

    def getFullName(self):
        return self.fullName

    def getBirthdate(self):
        return str(self.day) + "." + str(self.month) + "." + str(self.year)

    def getGender(self):
        return self.gender


class Phone:
    def __init__(self, num, mdl, wt):
        self.number = num
        self.model = mdl
        self.weight = wt

    def receiveCall(self, callerName):
        print("Звонит", callerName)

    def getNumber(self):
        return self.number

    def displayInfo(self):
        print("Номер:", self.number)
        print("Модель:", self.model)
        print("Вес:", self.weight)


class Reader:
    def __init__(self, name, cardNum, fac, bdate, ph):
        self.fullName = name
        self.readerCardNumber = cardNum
        self.faculty = fac
        self.birthdate = bdate
        self.phone = ph

    def takeBook(self, bookCount):
        print(self.fullName, "взял", bookCount, "книги.")

    def returnBook(self, bookCount):
        print(self.fullName, "вернул", bookCount, "книги.")

    def displayInfo(self):
        print("ФИО:", self.fullName)
        print("Номер читательского билета:", self.readerCardNumber)
        print("Факультет:", self.faculty)
        print("Дата рождения:", self.birthdate)
        print("Телефон:", self.phone.getNumber())


person = CPerson()
person.setFullName("Иванов Иван Иванович")
person.setBirthdate(15, 5, 1990)
person.setGender("Мужской")
print("ФИО:", person.getFullName())
print("Дата рождения:", person.getBirthdate())
print("Пол:", person.getGender())
print()

phone1 = Phone("555-1234", "iPhone 12", 0.2)
phone2 = Phone("555-5678", "Samsung Galaxy S21", 0.3)
phone3 = Phone("555-9999", "Google Pixel 6", 0.25)

phone1.receiveCall("Анна")
print("Номер телефона:", phone1.getNumber())
phone1.displayInfo()
print()

reader = Reader("Петров В. В.", "123456789", "ИТ", "01.01.1995", phone2)
reader.takeBook(3)
reader.displayInfo()
print()

phone3.receiveCall("Мария")
print("Номер телефона:", phone3.getNumber())